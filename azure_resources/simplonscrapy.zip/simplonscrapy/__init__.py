import subprocess

def main(req):
    subprocess.run(['scrapy', 'crawl', 'simplonFormations'], check=True)
    return 'Scrapy crawl a été exécuté avec succès !'
